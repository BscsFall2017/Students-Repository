#include <iostream>
using namespace std;
int main()
{
  int month, year;
  cout << "give the year \n";
  cin >> year;
  cout << "give the month\n";
  cin >> month;
  {
    switch (month)
    {
    case 1:
    cout << "number of day in month is 31\n";
    break;
    case 2:
    if (year % 4 == 0)
    {
          cout << "the number of days is 29 \n";
        }
        else
            {
          cout << "the number of days is 28 \n";
        }
        break;
      case 3: 5, 7, 8, 10, 12;
        cout << "the number of days is 31 \n";
        break;
      default:
        cout << "the number of days is 30 \n";
    }
  }
  return 0;
}
