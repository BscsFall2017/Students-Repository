#include<iostream>

using namespace std;

int main() {
	
	int age, number_of_accidents,cost,surcharge;
	int insurance_charge =500;
	
	cout<<"enter your age"<<endl;
	cin>>age;
	
	cout<<"number of accidents"<<endl;
	cin>>number_of_accidents;
	
	
//	if(age<25 ){
		
	//	cout<<"insurance charge is: "<<insurance_charge;
		
//	}
	
	
	         if (age<25 || number_of_accidents==1) {
		
	         	surcharge=500+100+50;
	          	cout<<"driver is under-aged and the net charge is: "<<surcharge;
		
		
	}
	 else
               	if (age<25 || number_of_accidents==2) {
		
		
	              	surcharge=500+125+100;
		            cout<<"driver is under-aged and the net charge is: "<<surcharge;
	}
	else
	
               	if (age<25 || number_of_accidents==3) {
		
		
	              	surcharge=500+225+100;
		            cout<<"driver is under-aged and the net charge is: "<<surcharge;
	
} else
	                          	if (age<25 || number_of_accidents==4) {
		
		
	              	surcharge=500+375+100;
		            cout<<"driver is under-aged and the net charge is: "<<surcharge;
	
} else
	
	               	if (age<25 || number_of_accidents==5) {
		
		
	              	surcharge=500+575+100;
		            cout<<"driver is under-aged and the net charge is: "<<surcharge;
	
} else
	
	               	if (age<25 || number_of_accidents>=6) {
		
		
	              	surcharge=0;
		            cout<<"no insurance";
	
}
	
	   
	
	
}
