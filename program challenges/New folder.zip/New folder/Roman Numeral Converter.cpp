#include <iostream>

using namespace std;

int main()
{

    int digit;

    cout << "enter number from 1 to 10 and I will tell you about its Roman numeral." << endl;
    cout << "Enter any digit from 1 to 10.\n";
    cin >> digit;

    switch (digit)
    {
        case 1 : cout << "The Roman Numeral for 1 is I";
        break;
        case 2 : cout << "The Roman Numeral for 2 is II";
        break;
        case 3 : cout << "The Roman Numeral for 3 is III";
        break;
        case 4 : cout << "The Roman Numeral for 4 is IV";
        break;
        case 5 : cout << "The Roman Numeral for 5 is V";
        break;
        case 6 : cout << "The Roman Numeral for 6 is VI";
        break;
        case 7 : cout << "The Roman Numeral for 7 is VII";
        break;
        case 8 : cout << "The Roman Numeral for 8 is VIII";
        break;
        case 9 : cout << "The Roman Numeral for 9 is IX";
        break;
        case 10 : cout << "The Roman Numeral for 10 is X";
        break;
        default: cout << "The number you entered is invalid.\n";
    }

    return 0;
}
