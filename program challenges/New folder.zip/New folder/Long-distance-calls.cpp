#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

    float starting_time, numberOfMinutes, charges, ratePerMinute;


    cout << "Enter the starting time in floating point number in the form of 'HH.MM'.\n";
    cin >> starting_time;
    cout << "Enter number of minutes of a call.\n";
    cin >> numberOfMinutes;


    if (starting_time > 00.00 && starting_time < 07.00)
    {
        ratePerMinute = 0.05;
        cout << "The charges for " << numberOfMinutes << " minutes are $" << numberOfMinutes * ratePerMinute << ".\n";
    }
    else if (starting_time >= 07.00 && starting_time<=19.00)
    {
        ratePerMinute = 0.45;
        cout << "The charges for " << numberOfMinutes << " minutes are $" << numberOfMinutes * ratePerMinute << ".\n";
    }
    else if (starting_time >= 19.01 && starting_time <= 23.59)
    {
        ratePerMinute = 0.20;
        cout << "The charges for " << numberOfMinutes << "minutes are $" << numberOfMinutes * ratePerMinute << ".\n";
    }
    else if (starting_time > 23.59)
    {
        cout << "Times greater than 23.59 will not be accepted. Sorry.\n";
    }
    return 0;
}
