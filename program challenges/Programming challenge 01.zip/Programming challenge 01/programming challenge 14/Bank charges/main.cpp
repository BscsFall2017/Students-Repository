#include <iostream>

using namespace std;

int main()
{
    int number,x=0;
    float amount,charges;
    cout <<"This Program will display\nThe Bank Service Fee for the month.\n "<< endl;
    cout << "Enter Amount Balance in your account:  \n";
    cin >> amount;
    cout << "You Entered $" << amount<< endl;
    cout << "Enter the Number of Checks written in the month:\n";
    cin >> number ;
    cout << "You Entered " << number << endl;
    if (amount<400)
        x=15;
    if (number <20)
    {
        charges=x+number * .10;
    cout << "The Monthly charges are $" << charges<< endl;
    }
    else if (number >=20&&number <39)
    {
        charges = x+number *.08;
        cout << "The Monthly charges are $" << charges<< endl;
    }
    else if (number >=40&& number <59)
    {
        charges =x+ number *.06;
        cout << "The Monthly charges are $" << charges<< endl;
    }
    else if (number >=60 )
    {
        charges = x+number *.04;
        cout << "The Monthly charges are $" << charges<< endl;

    }






    return 0;
}
