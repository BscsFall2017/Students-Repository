// AIMAN NAWAZ
#include <iostream>
using namespace std;
int main()
{
char letter = 'a';
cout << "this program will not terminate untill you press X. \n";
while (letter != 'x')
{
cout << "Please enter a letter" << endl;
cin >> letter;
cout << "The letter you entered is " << letter << endl;
}
return 0;
}
