#include <iostream>

using namespace std;

int main()
{
    float units_sold, total_cost, discount, costWOdiscount;
    int costPerPurchase;
    cout << "This program computes the total cost of the software purchase.\n";
    cout << "Enter the amount of units sold.\n";
    cin >> units_sold;

    if (units_sold < 0)
    {
     cout << "Make sure the number of units is greater than 0.";
    }
     else if (units_sold >= 10 && units_sold <20)
    {
        costWOdiscount = 99*units_sold;
        discount = ((20*100)/costWOdiscount);
        costPerPurchase = costWOdiscount-discount;
        cout << "You will have to pay $" << costPerPurchase << "." << endl;
    }

     else if (units_sold >= 20 && units_sold <=49)
    {
        costWOdiscount = 99*units_sold;
        discount = ((30*100)/costWOdiscount);
        costPerPurchase = costWOdiscount-discount;
        cout << "You will have to pay $" << costPerPurchase << "." << endl;
    }

     else if (units_sold >= 50 && units_sold <=99)
    {
        costWOdiscount = 99*units_sold;
        discount = ((40*100)/costWOdiscount);
        costPerPurchase = costWOdiscount-discount;
        cout << "You will have to pay $" << costPerPurchase << "." << endl;
    }

     else if (units_sold >= 100)
    {
        costWOdiscount = 99*units_sold;
        discount = ((50*100)/costWOdiscount);
        costPerPurchase = costWOdiscount-discount;
        cout << "You will have to pay $" << costPerPurchase << "." << endl;
    }

    return 0;
}
