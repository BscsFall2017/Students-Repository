// PLACE YOUR NAME HERE

#include <iostream>
using namespace std;

int main()
{
	char letter = 'a';
	cout<<"please enter the letters"<<endl;
	do
	{
           cin >> letter;
    cout << letter << endl;      
    }
    while (letter != 'x') ;

	return 0;	
}
