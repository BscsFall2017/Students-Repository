#include <iostream>

using namespace std;
int begngbelance;
int chargepermonth=10;
int checkfee;
double result;
int extracharge=15;
int numberofchecks;
double result1;
double result2;
double result3;
double result4;
double result5;
double result6;
double result7;
int main()
{
    cout<<"Enter the number of checks: "<<endl;
    cin>>numberofchecks;
    cout<<"Enter the beginning balance:"<<endl;
    cin>>begngbelance;



    if(begngbelance<0 && numberofchecks<0)
    cout<<"account is over drawn! "<<endl;




    if(numberofchecks<20 && begngbelance>400){
        result=chargepermonth+0.10;
      cout<<"SERVICE FEE:  "<<result<<endl;}
 if(numberofchecks<20 && begngbelance<400){
    result1=chargepermonth+0.10+15;
cout<<"service fee: "<<result1<<endl;

    }


     if(numberofchecks>=20 && numberofchecks<=39 &&begngbelance>400 ){
        result3=chargepermonth+0.08;
        cout<<"SERVICE FEE:  "<<result3<<endl;
    }

    if(numberofchecks>=20 && numberofchecks<=39 &&begngbelance<400 ){
        result2=chargepermonth+0.08+15;
        cout<<"SERVICE FEE:  "<<result2<<endl;
    }

     if(numberofchecks>=40 && numberofchecks<=59 && begngbelance>400){
        result4=chargepermonth+0.06;
        cout<<"SERVICE FEE:  "<<result4<<endl;
    }


      if(numberofchecks>=40 && numberofchecks<=59 && begngbelance<400){
        result5=chargepermonth+0.06+15;
        cout<<"SERVICE FEE:  "<<result5<<endl;
    }


     if(numberofchecks>=60 && begngbelance>400){
        result6=chargepermonth+0.04;
        cout<<"SERVICE FEE:  "<<result6<<endl;
    }


      if(numberofchecks>=60 && begngbelance<400){
        result7=chargepermonth+0.04+15;
        cout<<"SERVICE FEE:  "<<result7<<endl;
    }



    return 0;
}
