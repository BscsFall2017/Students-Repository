#include <iostream>

using namespace std;

int main()
{
int charge=500;
int surcharge=600;
int accharge1=50;
int accharge2=125;
int accharge3=225;
int accharge4=375;
int accharge5=575;
int age;
int number_of_accidents;
int result;



cout<<"Enter Driver's age"<<endl;
cin>>age;
cout<<"Enter number of accidents"<<endl;
cin>>number_of_accidents;

if(age<25){
    result=surcharge;
    cout<<result;
}else{
        result=charge;
        cout<<result;
}

if(number_of_accidents==1){
    result=result+accharge1;
    cout<<"+ 1 accident charge= "<<result;
}
if(number_of_accidents==2){
    result=result+accharge2;
    cout<<"+ 2 accident charge= "<<result;
}
if(number_of_accidents==3){
    result=result+accharge3;
    cout<<"+ 3 accident charge= "<<result;
}
if(number_of_accidents==4){
    result=result+accharge4;
    cout<<"+ 4 accident charge= "<<result;
}
if(number_of_accidents==5){
    result=result+accharge5;
    cout<<"+ 5 accident charge= "<<result;
}
if(number_of_accidents>=6){

    cout<<"\b\b\b you are Not eligible for insurance! \n\n\n";
}
return 0;
}
