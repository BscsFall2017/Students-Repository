//  This program has the user inputs two number n and m then finds the mean of that number
//  mean of the first n positive integers

// Ahsaan Elahi..172062

#include <iostream>
using namespace std;


int main()
{
 	int total = 0;
   	int number;
  	float mean=0,n ,m, value=0;

  	cout << "Please enter the First positive integer:" << endl;
   	cin >> n;
   	cout << "Please enter the Second Positive Integer:\n";
   	cin >> m;

  	if (m > 0 && n> 0)
  	{
      	for (number = n; number <= m; number++)
        {
 	  	    total = total + number;
		}  // curly braces are optional since there is only one statement
         value = (m -n)+ 1;
        mean = static_cast < float>(total) /value;

		cout << "The mean average of " << n << " and " << m <<" is \n"  << mean << endl;
    }
    else
        cout << "Invalid input - integer must be positive" << endl;

   return 0;
}
