#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	float time,
		   minutes,
		   rate;

	cout << setprecision(2) << fixed<<endl;
	
	cout << " Enter the Starting time of your call in this format: HH.MM, HH is hours and \n";
	cout << " MM is minutes:   ";
	cin >> time;
	if(time < 00.00 || time > 23.59)
	{
		cout << " Please enter a time between 00.00 hours and 23.59 hours." << endl;
		
	}
	
	if(time > 59)
	{
		cout << " The minutes in HH.MM cannot exceed 59." << endl;
		
	}		

	cout << "\n How many minutes was your call?  ";
	cin >> minutes;

	if(time >= 00.00 && time <= 06.59)
	{
		rate = 0.12;
		cout << " The rate of the starting time of call is " << rate << "." << endl;
	}
	else if(time >= 07.00 && time <= 19.00)
	{
		rate = 0.55;
		cout << " The rate of the starting time of call is " << rate << "." << endl;
	}
	else if(time >= 19.01 && time <= 23.59)
	{
		rate = 0.35;
		cout << " The rate of the starting time of call is " << rate << "." << endl;
	}


	system("pause");
	return 0;
}
