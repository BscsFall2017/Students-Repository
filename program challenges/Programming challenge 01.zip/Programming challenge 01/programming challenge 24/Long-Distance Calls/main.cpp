#include <iostream>

using namespace std;

int main()
{

    float number,stime,charges;
    cout << "This program will display Charges of Long-Distance calls." << endl;
    cout << "Enter the Starting time of the Call in the form of HH.MM :\n ";
    cin >> stime;
    cout << "Enter the Number of minutes of the call:\n";
    cin >> number;
    cout << "You Entered " << number << " minutes! \n";
    if (stime >23.59)
    {
        cout<< "Error!\nStart the program again and \nEnter the Valid time! \n";
        cout << "Witch should be Less than 23.59!\n";
    }
    else if (number>59)
    {
        cout << "Error!\nEnter the valid number of minutes!\n ";
        cout << "Witch should be less than 60!\n";
    }
    else if (stime>=00.00&&stime <=06.59)
    {
        charges=number *0.05;
        cout << "The total call charges are $" << charges <<endl;
    }
    else if (stime >=07.19&&stime <=19.00)
    {
        charges=number*0.45;
        cout << "The total call charges are $" << charges <<endl;
    }
    else if (stime>=19.01&&stime <23.59)
    {
        charges=number*0.20;
        cout << "The total call charges are $" << charges <<endl;
    }

    return 0;
}
