#include <iostream>

using namespace std;

int main()
{
    int num;
    cout<<"ENTER a number within range 1 to 10: "<<endl;
    cin>>num;
    switch (num)
    {
    case 1:
        cout<<"converted into roman :   I"<<endl;
         break;
         case 2:
        cout<<"converted into roman :   II"<<endl;
        break;
         case 3:
        cout<<"converted into roman :   III"<<endl;
        break;
        case 4:
        cout<<"converted into roman :   IV"<<endl;
        break;
         case 5:
        cout<<"converted into roman :   V"<<endl;
        break;
         case 6:
        cout<<"converted into roman :   VI"<<endl;
        break;
         case 7:
        cout<<"converted into roman :   VII"<<endl;
        break;
         case 8:
        cout<<"converted into roman :   VIII"<<endl;
        break;
         case 9:
        cout<<"converted into roman :   IX"<<endl;
        break;
         case 10:
        cout<<"converted into roman :   X"<<endl;
        break;
    }
    return 0;
}
