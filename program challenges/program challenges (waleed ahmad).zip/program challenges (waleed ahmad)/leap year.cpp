#include <iostream>
using namespace std;
int main() {
  
  int month, year;
  cout << "give the year \n";
  cin >> year;
  cout << "give the month(1-12)\n";
  cin >> month;


    switch (month) {
      case 1:
        cout << "number of day in month is 31\n";
        break;
      case 2:
        if (year % 4 == 0||year%400==0||year%100!=0) {
          cout << "the number of days is 29 \n";
        } else {
          cout << "the number of days is 28 \n";
        }
        break;
      case 3:
        cout << "the number of days is 31 \n";
        break;
        case 5:
        	cout<<"the number of days 31\n";
        	break;
        	case 7:
        		cout<<"the number of days 31 ";
        		break;
        		case 8:
        			cout<<"the number of days 31";
        			break;
        			case 10:
        			cout<<"the number of days 31";
        			break;
        			case 12:
        			cout<<"the number of days 31";
        			break;
      default:
        cout << "the number of days is 30 \n";
        
    }
  
  
}
