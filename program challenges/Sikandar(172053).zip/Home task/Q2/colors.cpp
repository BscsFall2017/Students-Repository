#include <iostream>

using namespace std;

int main()
{
    string clr1,clr2;
    cout<<" Enter two colors, then i will show you the mixture of these two  colors."<<endl;
    cin>> clr1;
    cin>> clr2;
    if(clr1=="red"&&clr2=="blue"||clr2=="red"&&clr1=="blue")
    {
        cout<<"Mixture of two colors  is (Purple)."<<endl;
    }
    else if(clr1=="red"&&clr2=="yellow"||clr2=="red"&&clr1=="yellow")
    {
        cout<<"Mixture of two is (Orange)."<<endl;
    }
    else if(clr1=="blue"&&clr2=="yellow"||clr2=="blue"&&clr1=="yellow")
    {
        cout<<"Mixture of two is (green)."<<endl;
    }
    else
    {
        cout<<"ERROR"<<endl;
    }
    return 0;
}
