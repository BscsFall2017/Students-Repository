#include <iostream>

using namespace std;

int main()
{
    string color1,color2;
    int red,blue,yellow;
    cout << "Please enter two primary colors" << endl;
    cout << "Enter color one" << endl;
    cin >> color1;
    cout << "Enter color two" << endl;
    cin >> color2;
    if(color1 == "red" && color2 == "blue")
    {
        cout << "The two colors make purple" << endl;
    }
    else if(color1 == "red" && color2 == "yellow")
    {
        cout << "The two colors make orange" << endl;
    }
    else if(color1 == "blue" && color2 == "yellow")
    {
        cout << "The two colors make green" << endl;
    }
    else
    {
        cout << "Invalid Input..." << endl;
    }
    return 0;
}
