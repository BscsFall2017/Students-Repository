#include <iostream>

using namespace std;
int month;
int year;
int main()
{
cout<<"Enter the number of month: "<<endl;
cin>>month;
cout<<"enter the year:"<<endl;
cin>>year;
if(month==2 && (year % 4 == 0) && !(year % 100 == 0)|| (year % 400 == 0)){
    cout<<"29 days"<<endl;
    cout<<"leap year."<<endl;
}

if(month==1 || month==3 || month==5 || month==7 || month==8 ||  month==10 || month==12){
    cout<<"31 days. "<<endl;
}
if(month==4 || month==6 || month==9 || month==11){
    cout<<"30 days."<<endl;
    }
    if (month==2){
        cout<<"28 days."<<endl;
    }
    return 0;
}
