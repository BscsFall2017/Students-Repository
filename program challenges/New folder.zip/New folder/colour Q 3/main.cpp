#include <iostream>

using namespace std;

int main()
{
    string colour1,colour2;
    cout<<"enter the two colour and i tell you the next colour"<<endl;
    cin>>colour1;
    cin>>colour2;


        if( colour1 =="red"&&colour2=="blue"||colour2=="red"&&colour1=="blue")
{
cout<<"these two colour mix up and get purple"<<endl;
    }
        else if(colour1=="red"&&colour2=="yellow"||colour2=="red"&&colour1=="yellow")
        {
cout<<"red and yellow mix up and get orange "<<endl;
}
else if (colour1=="blue"&&colour2=="yellow"||colour2=="blue"&&colour1=="elllow")
{
    cout<<"blue and yellow mix up and get green"<<endl;}
    else
    {
    cout<<"sorry this colours not match err0r!!!!"<<endl;

}
    return 0;
}
