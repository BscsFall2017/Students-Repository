#include <iostream>

using namespace std;

int main ()

{

int i = 10;

do

{

double calories = i * 3.90;

cout << calories << " calories burnt after " << i << " minute(s)" << endl;

i=i+5;

} while(i <= 30);

system("pause");

return 0;

}
