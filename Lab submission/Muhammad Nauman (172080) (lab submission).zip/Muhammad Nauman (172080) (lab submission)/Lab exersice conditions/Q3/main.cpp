#include <iostream>
#include<string>
using namespace std;

int main()
{
string word1;
string word2;
cout<<"Enter Two Words : "<<endl;
cin>>word1;
cin>>word2;
if(word1==word2){
    cout<<"Words are same: "<<endl;
}

word1.length();
word2.length();
if(word1.length()==word2.length()){
    cout<<"At least the same length."<<endl;
}
    return 0;
}
