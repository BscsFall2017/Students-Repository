#include <iostream>

using namespace std;
int month;
int year;
int main()
{
cout<<"Enter the number of month: "<<endl;
cin>>month;
cout<<"enter the year:"<<endl;
cin>>year;
if(month==2 && (year % 4 == 0) && !(year % 100 == 0)|| (year % 400 == 0)){
    cout<<"29 days"<<endl;
}

if(month==1){
    cout<<"31 days"<<endl;
}
if(month==2){
    cout<<"28 days"<<endl;
}

if(month==3){
    cout<<"31 days"<<endl;
}

if(month==4){
    cout<<"30 days"<<endl;
}

if(month==5){
    cout<<"31 days"<<endl;
}

if(month==6){
    cout<<"30 days"<<endl;
}
if(month==7){
    cout<<"31 days"<<endl;
}
if(month==8){
    cout<<"31 days"<<endl;
}
if(month==9){
    cout<<"30 days"<<endl;
}
if(month==10){
    cout<<"31 days"<<endl;
}
if(month==11){
    cout<<"30 days"<<endl;
}
if(month==12){
    cout<<"31 days"<<endl;
}
    return 0;
}
