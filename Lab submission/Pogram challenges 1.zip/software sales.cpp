#include <iostream>

using namespace std;

int main()
{
 int units;
 int sum;
 int totalcost;


 cout<<"How many units sold?"<<endl;
 cin>>units;


 if(units>=0 && units<=10)
 {
 totalcost=units*99;
 cout<<"Total cost of the purchase:"<< totalcost << endl;
 }
 else if(units>=10 && units<=19)
 {
 sum=(units*99)* .20;
 totalcost=(units*99)-sum;
 cout<<"Total cost of the purchase:" << totalcost << endl;
 }
 else if(units>=20 && units<=49)
 {
 sum=(units*99)* .30;
 totalcost=(units*99)-sum;
 cout<<"Total cost of the purchase:" << totalcost << endl;
 }
 else if(units>=50 && units<=99)
 {
 sum=(units*99)* .40;
 totalcost=(units*99)-sum;
 cout<<"Total cost of the purchase:" << totalcost << endl;
 }
 else if(units>=100)
 {
 sum=(units*99)* .50;
 totalcost=(units*99)-sum;
 cout<<"Total cost of the purchase:" << totalcost << endl;
 }
    return 0;
}
