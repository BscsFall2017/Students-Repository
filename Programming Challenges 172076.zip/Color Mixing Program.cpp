#include <iostream>
#include <string>

using namespace std;

int main()
{
    string color1, color2;
    cout << "Enter color one: ";
    cin >> color1;

    cout << "Enter color two: ";
    cin >> color2;

    if(color1 != color2){
            if(color1 == "red" || color2 == "red"){
                if(color1 == "blue" || color2 == "blue"){
                    cout << "The obtained color is purple." << endl;
                } else if(color1 == "yellow" || color2 == "yellow"){
                    cout << "The obtained color is orange." << endl;
                } else {
                    cout << "Invalid input" << endl;
                }
        } else if(color1 == "yellow" || color2 == "yellow"){
            if(color1 == "blue" || color2 == "blue"){
                cout << "The obtained color is green" << endl;
            }

        }
    } else {
        cout << "Invalid input" << endl;
    }

    return 0;
}
