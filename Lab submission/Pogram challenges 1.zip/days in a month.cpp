#include <iostream>

using namespace std;

int main()
{
    int month;
    int year;
    bool leapyear = false;
    int checkleapyear;
    cout << "Enter a month (1-12): ";
    cin >> month;
    cout << "Enter a year: ";
    cin >> year;
    if(month == 1)
    {
        cout << "January " << year << " has 31 days" << endl;
    }
    else if(month == 2 && leapyear == true)
    {
        cout << "February " << year << " has 29 days" << endl;
    }
    else if(month == 2 && leapyear == false)
    {
        cout << "February " << year << " has 28 days" << endl;
    }
    else if(month == 3)
    {
     cout << "March " << year << " has 31 days" << endl;
    }
    else if(month == 4)
    {
        cout << "April " << year << " has 30 days" << endl;
    }
    else if(month == 5)
    {
        cout << "May " << year << " has 31 days" << endl;
    }
    else if(month == 6)
    {
        cout << "June " << year << " has 30 days" << endl;
    }
    else if(month == 7)
    {
        cout << "July " << year << " has 30 days" << endl;
    }
    else if(month == 8)
    {
        cout << "August " << year << " has 31 days" << endl;
    }
    else if(month == 9)
    {
        cout << "September " << year << " has 30 days" << endl;
    }
    else if(month == 10)
    {
        cout << "October " << year << " has 31 days" << endl;
    }
    else if(month == 11)
    {
        cout << "November " << year << " has 30 days" << endl;
    }
    else if(month == 12)
    {
        cout << "December " << year << " has 31 days" << endl;
    }
    else
    {
        cout << " Invalid Month " << endl;
    }
    return 0;
}
