#include <iostream>
#include <string>

using namespace std;

int main()
{
	string color1, color2;

	cout << "Enter the first color : ";
	cin >> color1;

	cout << "Enter the second color : ";
	cin >> color2;

	if (color1 == "red" && color2 == "blue")
	{
		cout << "Those two colors make: Purple" << endl;
	}
	else if (color1 == "blue" && color2 == "yellow")
	{
		cout << "Those two colors make: Green" << endl;
	}
	else
	{
		cout << "Invalid Input....";
	}

}
