// Ch Jahanzaib
// programme for long call distance  
#include <iostream>
#include <iomanip> 
using namespace std;

int main()
{
	float time,minutes,rate,total;
	cout <<"Enter the time in this format:- HH:MM, HH is hours and MM is minutes: ";
	cin >> time;
	if(time < 00.00 || time > 23.59)
	{
		cout << " --- Enter Time between 00.00hours and 23.59hours --- " << endl;
	}
    else
    {
        cout << "\n\nEnter number of minutes of the Call: ";
        cin >> minutes;
        if(time >= 00.00 && time <= 06.59)
        {
            rate = 0.05;
        }
        else if(time >= 07.00 && time <= 19.00)
        {
            rate = 0.45;
        }
        else if(time >= 19.01 && time <= 23.59)
        {
            rate = 0.20;
        }
    total=minutes*rate;
    cout<<"The Total Charges are: "<<total;
    }
	return 0;
}
