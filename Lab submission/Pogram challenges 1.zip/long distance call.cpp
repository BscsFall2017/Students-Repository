#include <iostream>

using namespace std;

int main()
{
double time, time2, minutes, charges;
cout << "Enter the starting time of the call (HH.MM): ";
cin >> time;

time2 = time - static_cast<int>(time);  //gets the fractional part (minutes)

if(time2 > .59)
{
cout << "Starting time (minutes) cannot be greater than 59!!\n\n"
<< "Enter the time again (HH.MM): ";
cin >> time;
}

if(time > 23.59)
{
cout << "Starting time cannot be greater than 23:59!!\n\n"
<< "Enter the starting time again (HH.MM): ";
cin >> time;
}

cout << "Enter the duration of the call (minutes): ";
cin >> minutes;
if(minutes < 0)
{
cout << "Minutes cannot be less than 0!!\n\n"
<< "Enter the duration of the call (minutes) again: ";
cin >> minutes;
}
if(time >= 0.00 && time <= 06.59)
{
charges = minutes * 0.05;
cout << "Cost for the call: $" << charges << "\n\n";
}
if(time >= 07.00 && time <= 19.00)
{
charges = minutes * 0.45;
cout << "Cost for the call: $" << charges << "\n\n";
}
if(time >= 19.01 && time <= 23.59)
{
charges = minutes * 0.20;
cout << "Cost for the call: $" << charges << "\n\n";
}

system("pause");

return 0;
}
