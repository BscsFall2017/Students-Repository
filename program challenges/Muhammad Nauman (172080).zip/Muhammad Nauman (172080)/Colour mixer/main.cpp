#include <iostream>
#include <string>

using namespace std;

int main()
{
string color1;
string color2;
cout<<"ENTER the name of two  primary colors to get the secondary color: "<<endl;

cin>>color1;
cin>>color2;
if(color1=="red" && color2=="blue")
    cout<<"secondary color :  Purple"<<endl;
if (color1=="blue" && color2=="yellow")
        cout<<"Secondary color :  GREEN"<<endl;


if(color1=="red" && color2=="yellow")
    cout<<"Secondary color is:   orange  "<<endl
    ;
    return 0;
}
