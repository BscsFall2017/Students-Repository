#include <iostream>

using namespace std;

int main()
{
    int year,month;
    cout<<"Enter a month (1-12):"<<endl;
    cin>>month;
    cout<<"Enter a year:"<<endl;
    cin>>year;
    switch(month)
    {
    case 1:
        cout<<"31 days."<<endl;
        break;
    case 2:
        if(year%4==0)
            cout<<"29 days."<<endl;
        else
            cout<<"28 days."<<endl;
        break;
    case 3:
        cout<<"31 days."<<endl;
        break;
    case 4:
        cout<<"30 days."<<endl;
        break;
    case 5:
        cout<<"31 days."<<endl;
        break;
    case 6:
        cout<<"30 days."<<endl;
        break;
    case 7:
        cout<<"31 days."<<endl;
        break;
    case 8:
        cout<<"30 days."<<endl;
        break;
    case 9:
        cout<<"31 days."<<endl;
        break;
    case 10:
        cout<<"30 days."<<endl;
        break;
    case 11:
        cout<<"31 days."<<endl;
        break;
    case 12:
        cout<<"30 days."<<endl;
    default:
    cout<<"Invalid!"<<endl;
    }
    return 0;
}
