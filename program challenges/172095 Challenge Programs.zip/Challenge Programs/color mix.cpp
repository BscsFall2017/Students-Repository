#include<iostream>
using namespace std;
int main()
{
	char red='R', yellow='Y', blue='B', color1, color2;

	cout<<"The primary colors are: Red, Yellow, and Blue"<<endl;

	cout<<"\n\nIndicate two primary colors you wish to mix"<<endl;
	cout<<"\nEnter the initial of the first primary color, as a CAPITAL LETTER: ";
	cin>>color1;
	cout<<"\n\nEnter the intial of a second primary color, as a CAPITAL LETTER: ";
	cin>>color2;
	cout<<endl<<endl;

	if(color1==red)
	{
		if(color2==red)
		cout<<"Both colors you entered were RED"<<endl<<endl;

		else if(color2==yellow)
		cout<<"Mixing these colors will give ORANGE"<<endl<<endl;

		else if(color2==blue)
		cout<<"Mixing these colors will give PURPLE"<<endl<<endl;

		else
		cout<<"You didn't enter the initial of a primary color, or didn't use capital letters"<<endl<<endl;
	}

	else if(color1==yellow)
	{
		if(color2==red)
		cout<<"Mixing these colors will give ORANGE"<<endl<<endl;

		else if(color2==yellow)
		cout<<"Both colors you entered were  YELLOW"<<endl<<endl;

		else if(color2==blue)
		cout<<"Mixing these colors will give GREEN"<<endl<<endl;

		else
		cout<<"You didn't enter the initial of a primary color, or didn't use capital letters"<<endl<<endl;
	}

	else if(color1==blue)
	{
		if(color2==red)
		cout<<"Mixing these colors will give PURPLE"<<endl<<endl;

		else if(color2==yellow)
		cout<<"Mixing these colors will give GREEN"<<endl<<endl;

		else if(color2==blue)
		cout<<"Both colors you entered were  BLUE"<<endl<<endl;

		else
		cout<<"You didn't enter the initial of a primary color, or didn't use capital letters"<<endl<<endl;
	}

	else
		cout<<"You didn't enter the initial of a primary color, or didn't use capital letters"<<endl<<endl;
}

