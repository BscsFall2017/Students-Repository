#include <iostream>

using namespace std;

int main()
{
    double time,minutes,rate,total;
    total=rate*minutes;

    cout<<"enter the time in the format HH.MM:";
    cin>>time;
    cout<<"how many minutes was your call:";
    cin>>minutes;
    cout<<"display charges on the basis of duration of the call"<<endl;


    if(time>=00.00 && time<=06.59)
    {
        rate=0.5;
    cout<<"the rate of the starting time of call is"<<rate<<"."<<endl;
    cout<<"the total amount of call is:"<<total<<endl;}
    else if(time >=07.00 && time<=19.00)
    {
        rate=0.45;
        cout<<"the rate of starting time of call is"<<rate<<"."<<endl;
        cout<<"the total amount of call is:"<<total<<endl;
    }else if (time>=19.01 && time<=23.59)
    {
        rate=0.25;
        cout<<"the rate of starting time of call is"<<rate<<"."<<endl;
        cout<<"the total amount of call is:"<<total<<endl;
    }
}
