#include <iostream>

using namespace std;

int main()
{
    float units,totalcost,discount,package=99;
    cout<<"Enter the number of units sold:"<<endl;
    cin>>units;
    totalcost=package;
    if(units>0&&units<10)
    {
        totalcost=units*package;
        cout<<"Total cost is:"<<totalcost<<"$"<<endl;
    }
    else if(units>=10&&units<20)
    {
        totalcost=units*package;
        discount=(totalcost*20)/100;
        totalcost=totalcost-discount;
        cout<<"Total cost is: "<<totalcost<< "$"<<endl;
    }
    else if(units>=50&&units<100)
    {
        totalcost=units*package;
        discount=(totalcost*40)/100;
        totalcost=totalcost-discount;
        cout<<"total cost is: "<<totalcost<<"$"<<endl;
    }
    else if(units>=100)
    {
        totalcost=units*package;
        discount=(totalcost*50)/100;
        totalcost=totalcost-discount;
        cout<<"Total cost is: "<<totalcost<<"$"<<endl;
    }
    else
        cout<<"ERROR."<<endl;
    return 0;
}
