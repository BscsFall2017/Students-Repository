#include <iostream>

using namespace std;

int main()
{
    int num;
    cout<<"enter the num and i will tell you roman value"<<endl;
    cin>>num;
    switch(num)
{
    case (1):
    cout<<"the roman value is (i)"<<endl;
    break;
    case(2):
    cout<<"the roman value is (ii)"<<endl;
    break;
    case(3):
    cout<<"the roman value is (III)"<<endl;
    break;
    case(4):
     cout<<"the roman value is (iv)"<<endl;
    break;
    case(5):
     cout<<"the roman value is (v)"<<endl;
    break;
    case(6):
     cout<<"the roman value is (vi)"<<endl;
    break;
    case(7):
     cout<<"the roman value is (vii)"<<endl;
    break;
    case(8):
     cout<<"the roman value is (viii)"<<endl;
    break;
    case(9):
     cout<<"the roman value is (ix)"<<endl;
    break;
    case(10):
     cout<<"the roman value is (x)"<<endl;
    break;
    default:
    cout<<"enter num is invaild "<<endl;
}
    return 0;
}
