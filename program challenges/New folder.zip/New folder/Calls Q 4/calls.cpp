#include <iostream>

using namespace std;

int main()
{
    float time,rate,minutes;
    cout<<"Enter the time:"<<endl;
    cin>>time;
    if(time<00.00||time>23.59)
    {
        cout<<"Enter time between 00.00hours and 23.59hours"<<endl;
    }
    else
    {
        cout<<"Enter number of minutes of the call:"<<endl;
        cin>> minutes;
    }
            if(time>=00.00&& time<=06.59)
    {
        rate=0.05;
    }
    else if(time>=07.00&&time<=19.00)
    {
        rate=0.45;
    }
    else if(time>=19.01&&time<=23.59)
    {
        rate=0.20;
    }
    return 0;
}
