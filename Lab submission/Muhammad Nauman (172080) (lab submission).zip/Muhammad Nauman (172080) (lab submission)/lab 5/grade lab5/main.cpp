#include <iostream>

using namespace std;

int main()
{
char grade;
cout<<"ENTER your grade:"<<endl;
cin>>grade;
if(grade=='A')
{
    cout<<"EXCELENT"<<endl;
}
else if(grade=='B'){
    cout<<"GOOD"<<endl;
}
else{
    cout<<"work hard"<<endl;
}
    return 0;
}
