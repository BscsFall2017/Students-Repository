#include <iostream>
using namespace std;

int main()
{

double quantity, package_cost,discount;
package_cost= 99;


cout << "How many units sold? ";
cin >> quantity;
cout<<"enter the discount value: ";
cin>>discount;
if ( quantity >= 10 && quantity <= 19)
{

cout << "Total cost is: " << package_cost*quantity*discount << endl;
}
else if ( quantity >= 20 && quantity <= 49)
{

cout << "Total cost is: " <<package_cost*quantity*discount << endl;
}
else if ( quantity >= 50 && quantity <= 99)
{

cout << "Total cost is: " << package_cost*quantity*discount<< endl;
}
else if ( quantity > 100 )
{

cout << "Total cost is: " << package_cost*quantity*discount << endl;
}
else
{

cout << "Total Cost is " << package_cost * quantity << endl;}

return 0;
}

