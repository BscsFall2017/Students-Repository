#include <iostream>

using namespace std;

int main()
{
    int num;
    cout<<"Enter a number:"<<endl;
    cin>> num;
    switch (num)
    {
        case (1):
        cout<<"The roman value is (i)."<<endl;
        break;
        case (2):
        cout<<"The roman value is (ii)."<<endl;
        break;
        case (3):
        cout<<"The roman value is (iii)."<<endl;
        break;
        case (4):
        cout<<"the roman value is (iv)."<<endl;
        break;
        case (5):
        cout<<"The roman value is (v)."<<endl;
        break;
        case (6):
        cout<<"The roman value is (vi)."<<endl;
        break;
        case (7):
        cout<<"The roman value is (vii)."<<endl;
        break;
        case (8):
        cout<<"The roman value is (viii)."<<endl;
        break;
        case (9):
        cout<<"the roman value is (ix)."<<endl;
        break;
        case (10):
        cout<<"The roman value is (x),"<<endl;
        break;
        default:
            cout<<"The entered number is Invalid."<<endl;
    }
    return 0;
}
