//  This program has the user input a number n and then finds the
//  mean of the first n positive integers

// Irsam
#include <iostream>
using namespace std;
int main()
{
	int value,i,j=0;       // value is some positive number n
 	int total = 0;   // total holds the sum of the first n positive numbers
   	int number;      // the amount of numbers
  	float mean;      // the average of the first n positive numbers
    cout << "Please enter a starting positive integer" << endl;
   	cin >> number;
  	cout << "Please enter a ending positive integer" << endl;
   	cin >> value;
  	if (value > 0)
  	{
      	for (i=number; i<= value; i++)
        {
 	  	    total = total + i;
 	  	    j++;
		}
        mean = float(total) / j;         // note the use of the typecast
        //mean=total/value;             // operator here
		cout << "The mean average is " << mean << endl;
    }
    else
        cout << "Invalid input - integer must be positive" << endl;
   return 0;
}
