#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	float StartTime, Length, Mins, Hrs, Charges, StartMins, LengthInMins;


	cout << "This program will calculates your long-distance telephone charges.\n";
	cout << "Enter the starting time of the call as a floating-point number\n"
		 << "in the form HH.MM: ";
	cin  >> StartTime;
	cout << "Enter the number of minutes of the call in the form HH.MM: ";
	cin  >> Length;

	Hrs = static_cast<int>(Length);
	Mins = Length - static_cast<int>(Length);
	LengthInMins = (Hrs * 60) + (Mins * 100);
	StartMins = StartTime - static_cast<int>(StartTime);

	if (Mins <= .59 && StartMins <= .59)
	{
		cout << fixed << showpoint << setprecision(2);
		if (StartTime >= 00.00 && StartTime <= 06.59)
		{
			Charges = LengthInMins * 0.05;
			cout << "Cost of call: $" << Charges << endl;
		}
		else if (StartTime <= 19.00)
		{
			Charges = LengthInMins * 0.45;
			cout << "Cost of call: $" << Charges << endl;
		}
		else if (StartTime <= 23.59)
		{
			Charges = LengthInMins * 0.20;
			cout << "Cost of call: $" << Charges << endl;
		}
		else
			cout << "Error! Call times cannot be less than\n00.00 minutes"
		         << " or greater than 23.59 minutes.\n";
	}
	else
		cout << "Error! Last two digits in the numbers"
			 << " must be less than 59.\n";
	return 0;
}

