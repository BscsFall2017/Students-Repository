#include <iostream>

using namespace std;

int main()
{
   float bank_blc;
   float check_written;
   float minimum_blc=400;
   float charge_pc;
   const int extra_fee=15;

   cout<<"There is a payment of $10 per month for this account."<<endl;
   cout<<"What is your balance and how many checks have you written?"<<endl;
   cin>>check_written;
   cout<<"Enter your bank balance: ";
   cin>>bank_blc;

   if(bank_blc<400)
   {
       bank_blc+extra_fee;
       cout<<"Sorry there is a charge of $15\n";
       cout<<"if you have a balance that is \n";
       cout<<"below $400\n\n";
       cout<<"your current balance is: "<<bank_blc<<endl;

   }else if(bank_blc>=400)
   {
       cout<<"Your current balance is: "<<bank_blc<<endl;
   }if(check_written<20)
   {charge_pc+.10;
   cout<<"There is a charge of 10 cents\n";
   cout<<"for checks that are 20 or less.";

   }else if (check_written>20 && check_written<39)
   {
       charge_pc+.08;
       cout<<"There is a charge of 8 cents for\n"
       <<"20 to 39 written checks.";

   }else  if(check_written>40 && check_written<59)
   {
       charge_pc+.06;
       cout<<"There is charge of 6 cents for\n"
       <<"40 to 59 written checks.";
   }

}
