#include <iostream>
using namespace std;
int main()
{
int checks = 0;
double balance,fee;
    cout << "Hello What's Your Balance? "<<endl;
    cin >> balance;


    if (balance <400 && balance >=0) {
    cout << "HOW MANY CHECKS HAVE YOU WRITTEN?";
    cin >> checks;
    if (checks < 0) {
        cout<<"Can't do that";
    }

    if (checks < 20 ) {
    fee = .10 * checks + 10 + 15;

     cout << " Bank Service charges for the month is "<< fee << " Dollars ";
    }
    else if (checks <=39 && checks >=20){
    fee = .08 * checks + 10 + 15;
    cout << " Bank Service charges for the month is "<< fee << " Dollars ";

    }else if (checks <=59 && checks >=40 ){
    fee = .06 * checks + 10 + 15;
    cout << " Bank Service charges for the month is "<< fee << " Dollars ";
    }else if (checks >60 ){
    fee = .04 * checks + 10 + 15;
    cout << " Bank Service charges for the month is "<< fee << " Dollars ";
    }

    else {
fee = .10 * checks + 10 + 15;
cout << " Bank Service charges for the month is "<< fee << " Dollars ";
}
    }
    else if ( balance >=400){
        cout << "HOW MANY CHECKS HAVE YOU WRITTEN?";
        cin >> checks;



        if (checks < 20) {
    fee = .10 * checks + 10  ;

     cout << " Bank Service charges for the month is "<< fee << " Dollars ";
    }
    else if (checks <=39 && checks >=20){
    fee = .08 * checks + 10 ;
    cout << " Bank Service charges for the month is "<< fee << " Dollars ";

    }else if (checks <=59 && checks >=40 ){
    fee = .06 * checks + 10 ;
    cout << " Bank Service charges for the month is "<< fee << " Dollars ";
    }else if (checks >60 ){
    fee = .04 * checks + 10 ;
    cout << " Bank Service charges for the month is "<< fee << " Dollars "<<endl;
    }
    else
    {
fee = .10 * checks + 10 ;
cout << " Bank Service charges for the month is "<< fee << " Dollars ";
}
    }
    }
