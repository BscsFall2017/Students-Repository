#include <iostream>

using namespace std;

int main()
{int number;
    cout<<"Roman numeral converter"<<endl;
    cout<<"enter number (1-10)"<<endl;
    cin>>number;
    while (number<1||number>10){
        cout<<"please enter a valid number"<<endl;
        cin>> number;}
        switch(number){
            case 1:cout<<" the roman numeral version of " << number <<" is I"<<endl;
            break;
            case 2:cout<<" the roman numeral version of " << number <<" is II"<<endl;
            break;
            case 3:cout<<" the roman numeral version of " << number <<" is III"<<endl;
            break;
            case 4:cout<<" the roman numeral version of " << number <<" is IV"<<endl;
            break;
            case 5:cout<<" the roman numeral version of " << number <<" is V"<<endl;
            break;
            case 6:cout<<" the roman numeral version of " << number <<" is VI"<<endl;
            break;
            case 7:cout<<" the roman numeral version of " << number <<" is VII"<<endl;
            break;
            case 8:cout<<" the roman numeral version of " << number <<" is VIII"<<endl;
            break;
            case 9:cout<<" the roman numeral version of " << number <<" is IX"<<endl;
            break;
            case 10:cout<<" the roman numeral version of " << number <<" is X"<<endl;
            break;
            default: cout<<"Invalid number"<<endl;
    }
}
