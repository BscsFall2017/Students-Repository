#include <iostream>

using namespace std;

int main()
{
int month ,years;
cout<<"enter the month (1-12)"<<endl;
cin>>month;
cout<<"enter the year"<<endl;
cin>>years;

switch(month)
{


case 1:
cout<<"31 days  "<<endl;
  break;
case 2:
if(years%4==0)

       cout<<"29 days."<<endl;

else
    cout<<"28 days" <<endl;
break;
case(3):
    cout<<" days 31"<<endl;
    break;
case(4):
    cout<<"days 30"<<endl;
    break;
case(5):
    cout<<"days 31"<<endl;
    break;
case(6):
    cout<<"days 30"<<endl;
    break;
    case(7):
    cout<<"days 31"<<endl;
    break;
    case 8:
    cout<<"days 30"<<endl;
    break;
    case 9:
        cout<<"days 31"<<endl;
        break;
    case 10:
        cout<<"days 30 "<<endl;
        break;
    case 11:
    cout<<"days  31"<<endl;
    break;
    case 12:
    cout<<"days 30 "<<endl;
    break;

    default:
        cout<<"number is invalid "<<endl;
}
}


