#include <iostream>
using namespace std;


int main()
{
    int number;
    cout << "Enter a number from 1 to 10" << endl;
    number >=1 <=10;
    cin >> number;
    switch(number)
    {
    case 1:
    cout <<"i";
    break;
    case 2:
    cout << "ii";
    break;
    case 3:
    cout << "iii";
    break;
    case 4:
    cout << "iv";
    break;
    case 5:
    cout<< "v";
    case 6:
    cout <<"vi";
    break;
    case 7:
    cout <<"vii";
    break;
    case 8:
    cout << "viii";
    break;
    case 9:
    cout << "ix";
    break;
    case 10:
    cout <<"x";
    break;
    default:
        cout<<"The number you entered is not in range";}



    return 0;
}
