#include <iostream>

using namespace std;

int main()
{
    float balance,checks;
    cout << "This program will calculate monthly bank service fees" << endl;
     cout<<"Enter the balance "<<endl;
     cin>>balance;



 cout<<"enter the number of checks"<<endl;
     cin>>checks;







     if (balance >=400&&checks>=1&&checks<=20)
      {

        cout<<"total fees"<<"$"<<.10+10;}

else{
    if (balance <400&&balance>0&&checks>=1&&checks<=20)
    cout<<"total fees"<<"$"<<.10+10+15;

    if(balance<0)
        cout<<" account withdrawn ";
}


         if (balance >=400&&checks>=20&&checks<=39)
      {

        cout<<"total fees"<<"$"<<.08+10;}
else{

if (balance <=400&&balance>0&&checks>=20&&checks<=39)
  cout<<"total fees"<<"$"<<.08+10+15;


}


         if (balance >=400&&checks>=40&&checks<=59)
      {

        cout<<"total fees"<<"$"<<.06+10;}

else{

    if (balance <400&&balance>0&&checks>=40&&checks<=59)


    cout<<"total fees"<<"$"<<.06+10+15;


}
         if (balance >=400&&checks>=60)
      {

        cout<<"total fees"<<"$"<<.04+10;}


        else{

            if (balance <400&&balance>0&&checks>=60)



              cout<<"total fees"<<"$"<<.04+10+15;

        }






 }
