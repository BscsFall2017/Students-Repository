#include <iostream>
using namespace std;
int main()
{
 int units;
 int sum;
 int tsum;
 
 
 cout<<"how many units saled"<<endl;
 cin>>units;
 
 
 if(units>0 && units<10)
 {
 tsum=units*99;
 cout<<"your total sumis "<<tsum<<endl;
 
 
 }
 else if(units>=10 && units<=19)
 {
 sum=(units*99)* .20;
 tsum=(units*99)-sum;
 cout<<"your total sumis "<<tsum<<endl;
 
 }
 else if(units>=20 && units<=49)
 {
 sum=(units*99)* .30;
 tsum=(units*99)-sum;
 cout<<"your total sumis "<<tsum<<endl;
 
 }
 else if(units>=50 && units<=99)
 {
 sum=(units*99)* .40;
 tsum=(units*99)-sum;
 cout<<"your total sumis "<<tsum<<endl;
 
 }
 else if(units>=100)
 {
 sum=(units*99)* .50;
 tsum=(units*99)-sum;
 cout<<"your total sum $ "<<tsum<<endl;
 
 }
 
 
 
}
