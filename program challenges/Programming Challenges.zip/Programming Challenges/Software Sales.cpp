#include <iostream>
using namespace std;
int main()
{
float numberOfUnits, totalCost,discount, package=99;

   cout <<"Enter the Number of Units Sold: ";
   cin >>numberOfUnits;

   totalCost=package;

   if (numberOfUnits>0 && numberOfUnits<10)
    {
        totalCost=numberOfUnits*package;
        cout<<"The Total cost is: "<<totalCost<<"$"<<endl<<endl;
    }

  else if (numberOfUnits>=10 && numberOfUnits<20)
    {
        totalCost=numberOfUnits*package;
        discount = (totalCost*20)/100;
        totalCost=totalCost-discount;
        cout<<"The Total cost is: "<<totalCost<<"$"<<endl<<endl;
    }

  else if (numberOfUnits>=20 && numberOfUnits<50)
    {
        totalCost=numberOfUnits*package;
        discount = (totalCost*30)/100;
        totalCost=totalCost-discount;
        cout<<"The Total cost is: "<<totalCost<<"$"<<endl<<endl;
    }

  else if (numberOfUnits>=50 && numberOfUnits<100)
    {
        totalCost=numberOfUnits*package;
        discount = (totalCost*40)/100;
        totalCost=totalCost-discount;
        cout<<"The Total cost is: "<<totalCost<<"$"<<endl<<endl;
    }
  else if (numberOfUnits>=100)
    {
        totalCost=numberOfUnits*package;
        discount = (totalCost*50)/100;
        totalCost=totalCost-discount;
        cout<<"The Total cost is: "<<totalCost<<"$"<<endl<<endl;
    }
  else
    cout<<"Error!";

   return 0;
}
