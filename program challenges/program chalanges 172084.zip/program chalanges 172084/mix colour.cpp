#include <iostream>
#include <string>

using namespace std;

int main()
{
	string color1, color2;

	cout << "Input color 1: ";
	getline(cin, color1);

	cout << "Input color 2: ";
	getline(cin, color2);

	if (color1 == "red" && color2 == "blue")
	{
		cout << "Those two colors make: Purple" << endl;
	}
	else if (color1 == "blue" && color2 == "yellow")
	{
		cout << "Those two colors make: Green" << endl;
	}
	else
	{
		cout << "Invalid Input....";
	}
	cin.get();
}
