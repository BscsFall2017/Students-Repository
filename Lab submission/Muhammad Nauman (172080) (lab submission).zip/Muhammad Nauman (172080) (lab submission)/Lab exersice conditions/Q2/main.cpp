#include <iostream>

using namespace std;

int main()
{


int numb;
int limt=6;7;9;
cout<<"enter your number"<<endl;
cin>>numb;
if(numb==limt || numb>33){

    cout<<"good";
    }
    else


cout<<"bad";

    return 0;
}
