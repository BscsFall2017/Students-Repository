#include <iostream>

using namespace std;

int main()
{
    int prcnt;
cout<<"ENTER your percentage:"<<endl;
cin>>prcnt;
if(prcnt>=80){
    cout<<"DISTINCTION"<<endl;
}
else if(prcnt>=60 && prcnt<80){
    cout<<"FIRST DIVISON"<<endl;

}
else if(prcnt>=50 && prcnt<60)
{

    cout<<"SECOND Division"<<endl;
}
else if(prcnt>=40 && prcnt<50){
    cout<<"Third Devision"<<endl;
}
else if(prcnt<40){
    cout<<"FAIL"<<endl;
}
    return 0;
}
