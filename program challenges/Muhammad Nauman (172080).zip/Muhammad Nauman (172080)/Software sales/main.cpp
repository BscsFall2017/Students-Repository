#include <iostream>
#include<cmath>

using namespace std;
int number;
int price;
double discount;
double pay;

int main()
{
cout<<"enter number of software: "<<endl;
cin>>number;
price=number*99;
cout<<"price is: "<<price<<endl;

if(number>=10 && number<=19){
    discount=(20*price)/100;
    pay=price-discount;
    cout<<"discount is: "<<discount<<endl;
    cout<<"you have to pay: "<<pay<<endl;
}

if(number>=20 && number<=49){

  discount=(30*price)/100;
    pay=price-discount;
    cout<<"discount is: "<<discount<<endl;
    cout<<"you have to pay: "<<pay<<endl;

}

if(number>=50 && number<=99){

    discount=(40*price)/100;
    pay=price-discount;
    cout<<"discount is: "<<discount<<endl;
    cout<<"you have to pay: "<<pay<<endl;
}

if(number>=100){

    discount=(50*price)/100;
    pay=price-discount;
    cout<<"discount is: "<<discount<<endl;
    cout<<"you have to pay: "<<pay<<endl;
}





    return 0;
}
