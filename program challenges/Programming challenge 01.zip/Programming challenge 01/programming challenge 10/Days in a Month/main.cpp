#include <iostream>

using namespace std;

int main()
{
    int m , y,x=28;
    cout << "Please inter the Month and Year \n";
    cout << " The program will display the number of days in that Month." << endl;
    cout <<"Enter the month: \n";
    cin >> m;
    cout << "Enter the Year: \n";
    cin >> y;
    if (y%400==0 || ( y%4==0 && y%100 !=0 ))
       x=28+1;
    switch ( m )
    {
        case 1: cout << "In january there are 31 days! \n";
                break;
        case 2: cout << "In Second month there are "<< x << " days! \n";
                 break;
        case 3: cout << "In Third month there are 31 days! \n";
                 break;
        case 4: cout << "In 4th month there are 30 days! \n";
                 break;
        case 5: cout << "In 5th month there are 31 days! \n";
                 break;
        case 6: cout << "In 6th month there are 30 days! \n";
                 break;
        case 7: cout << "In 7th month there are 31 days! \n";
                 break;
        case 8: cout << "In 8th month there are 31 days! \n";
                break;
        case 9: cout << "In 9th month there are 30 days! \n";
                 break;
        case 10: cout << "In 10th month there are 31 days! \n";
                break;
        case 11: cout << "In 11th month there are 30 days! \n";
                 break;
        case 12: cout << "In 12th month there are 31 days! \n";
                break;

    }

    return 0;
}
