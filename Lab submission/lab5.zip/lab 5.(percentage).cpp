#include <iostream>
#include <conio.h>
using namespace std;

int main()
{
    float percent;
    cout<<"Enter your percentage: ";
    cin>>percent;
    cout<<"You scored "<<percent<<"%"<<endl;   
    if (percent>=80)
    {
        cout<<"You have passed with distinction";
    }    
    else if (percent>=60)
    {
        cout<<"You have passed with first division";
    }
    else if (percent>=50)
    {
        cout<<"You have passed with second division";
    }
    else if (percent>=40)
    {
        cout<<"You have passed with third division";
    }
    else
    {
        cout<<"Sorry: You have failed";
    }
    getch();
    return 0;
}
