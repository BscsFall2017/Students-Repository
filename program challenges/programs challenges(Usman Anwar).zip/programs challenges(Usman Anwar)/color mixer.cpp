#include<iostream>
#include<string>
using namespace std;
int main()
{
 int  colors;
 string primary_color_red= "red";
 string primary_color_blue= "blue";
 string primary_color_yellow ="yellow";
 
 cout<<"Enter the two primary colors"<<endl;
cin>>primary_color_red>>primary_color_blue;

if (primary_color_red =="red" && primary_color_blue == "blue"){
	
	cout<<"purple";
	
}
	else
           	if(primary_color_red =="red" && primary_color_yellow == "yellow"){
	
               	cout<<"orange";
	}
        else 
	            if(primary_color_blue =="blue" && primary_color_yellow == "yellow"){
	
	                  cout<<"green";
					  }
	else {
	
	
		cout<<"ERROR MESSAGE";
	}	

}

