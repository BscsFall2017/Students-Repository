// PLACE YOUR NAME HERE

#include <iostream>
using namespace std;

int main()
{
	char tletter= 'a';
	char letter;
	cout << "Enter a Letter & program will show you letter you will input.\n ";
	cout << "Until you have to put x to terminate the program. ";

    while (letter!='x')
	{
	    cout << "Please enter a letter" << endl;
       cin >> letter;
           cout << "The letter you entered is " << letter << endl;
    }

    return 0;
}
