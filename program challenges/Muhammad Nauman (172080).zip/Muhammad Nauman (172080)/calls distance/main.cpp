#include <iostream>

using namespace std;
float startingtime(00.00-23.59);
float time(00.00-23.59);
float charges1;
float charges2;
float charges3;

int main()
{
    cout<<"Enter the starting time: "<<endl;
cin>>startingtime;
cout<<" Enter the Duration of the call: "<<endl;
cin>>time;


if(startingtime>=00.00 && time<=06.59){
    charges1=(time-startingtime)*0.05;
    cout<<"charges are :"<<charges1<<endl;
}


if(startingtime>=07.00 && time<=19.00){
    charges2=(time-startingtime)*0.45;
    cout<<"charges are :"<<charges2<<endl;
}

if(startingtime>=19.01 && time<=23.59){
    charges3=(time-startingtime)*0.20;
    cout<<"charges are :"<<charges3<<endl;
}





}
