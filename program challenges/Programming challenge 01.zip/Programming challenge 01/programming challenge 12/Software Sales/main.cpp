#include <iostream>

using namespace std;

int main()
{
    int number , x=99 ,cost;
    float discount,tcost;
    cout << "Enter the total number of sold packages units. " << endl;
    cout << "This program will provide you the total cost of purchase.\n ";
    cin >> number;
    cout << " You Entered: " << number << endl;
    cost = number * x;
    if (number >=0 && number <10)
    {
        discount = ( cost *0)/100;
        tcost =cost - discount;
        cout << "The cost is "<< cost << endl;
        cout << "The discount is $" << discount << endl;
        cout << "After the Discount \n The total cost of purchase is $" << tcost << endl;
    }
    else if (number >=10&& number<=19 )
    {
        discount =  (cost*20)/100;
         tcost =cost - discount;
        cout << "The cost is "<< cost << endl;
        cout << "The discount is $" << discount << endl;
        cout << "After the Discount \n The total cost of purchase is $" << tcost << endl;
    }
    else if (number >=20&& number <=49)
    {
        discount = cost*(30/100);
         tcost =cost - discount;
        cout << "The cost is "<< cost << endl;
        cout << "The discount is $" << discount << endl;
        cout << "After the Discount \n The total cost of purchase is $"<< tcost<< endl;
    }
    else if (number >=50&& number <=99)
    {
        discount =cost *(40/100);
         tcost =cost - discount;
        cout << "The cost is "<< cost << endl;
        cout << "The discount is $" << discount << endl;
        cout << "After the Discount \n The total cost of purchase is $" << tcost << endl;
    }
    else if(number >=100)
    {
        discount = cost *(50/100);
         tcost =cost - discount;

        cout << "The cost is "<< cost << endl;
        cout << "The discount is $" << discount << endl;
        cout << "After the Discount \n The total cost of purchase is $" << tcost << endl;
    }
    else
        cout << "You have input an Invalid number!";
        cout << "\n Negative numbers are not allowed!";


    return 0;
}
