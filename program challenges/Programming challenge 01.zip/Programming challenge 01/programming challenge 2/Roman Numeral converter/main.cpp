#include <iostream>

using namespace std;

int main()
{
    int x;
    cout << "Enter A Number with in the range of 1 to 10.\n";
    cout << "The program will display the Roman Numeral version of that Number. " << endl;
    cout << "Lets start!"<< endl;
    cin >> x;
    if ( (x>= 0) && (x<=10))
    {
    cout << "The Roman numeral version of " << x << " is ";

    switch (x)
    {
        case 1: cout << " i \n " ;
               break;
        case 2: cout << " ii \n";
                break;
        case 3: cout << " iii \n";
                break;
        case 4: cout << " iv \n";
                break;
        case 5: cout << " v \n";
                break;
        case 6: cout << " vi \n";
                break;
        case 7: cout << " vii \n";
                break;
        case 8: cout << " viii \n";
                break;
        case 9: cout << " ix \n";
                break;
        case 10: cout << " x \n";
    }
    }
    else
    {
        cout << " You are only allowed to input the number in \n ";
                 cout << "range of 1 to 10 "<< endl;
    }



    return 0;
}
