#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    //Declare the variables.
    float starting_time, numberOfMinutes, charges, ratePerMinute;
    //Get input from the user
    cout << "Enter the starting time in floating point number in the form 'HH.MM'.\n";
    cin >> setprecision(2) << starting_time;
    cout << "Enter the number of minutes of the call.\n";
    cin >> numberOfMinutes;


    //Apply conditions
    if (starting_time > 00.00 && starting_time < 07.00)
    {
        ratePerMinute = 0.05;
        cout << "The charges for " << numberOfMinutes << " minutes are $" << numberOfMinutes * ratePerMinute << ".\n";
    }
    else if (starting_time >= 07.00 && starting_time<=19.00)
    {
        ratePerMinute = 0.45;
        cout << "The charges for " << numberOfMinutes << " minutes are $" << numberOfMinutes * ratePerMinute << ".\n";
    }
    else if (starting_time >= 19.01 && starting_time <= 23.59)
    {
        ratePerMinute = 0.20;
        cout << "The charges for " << numberOfMinutes << " minutes are $" << numberOfMinutes * ratePerMinute << ".\n";
    }
    else if (starting_time > 23.59)
    {
        cout << "Times greater than 23.59 are not accepted. Sorry.\n";
    } else
    {
        cout << "The input is invalid.\n";

    }
    return 0;
}
