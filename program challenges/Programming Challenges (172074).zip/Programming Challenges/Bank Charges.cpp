#include <iostream>
using namespace std;
int main()
{
float balance, numberOfChecks, balanceFee, checksFee,total;
cout<<"Enter Your Balance: ";
cin>>balance;
if(balance<0)
{
    cout<<"--> Your Account is OverDrawn <--"<<endl<<endl;
}
else
{
    if (balance>=0 && balance<400)
    {
        balanceFee=15;
    }
    cout<<"Enter the Number of Checks written: ";
    cin>>numberOfChecks;

        if(numberOfChecks<0)
            {
                cout <<"Error!"<<endl<<endl;
            }
        else
            {
                if(numberOfChecks>= 0 && numberOfChecks < 20)
                    checksFee = numberOfChecks * 0.10;
                else if(numberOfChecks >= 20 && numberOfChecks <40)
                    checksFee = numberOfChecks * 0.08;
                else if(numberOfChecks >= 40 && numberOfChecks <60)
                    checksFee = numberOfChecks * 0.06;
                else if(numberOfChecks >= 60)
                    checksFee = numberOfChecks * 0.04;

        total = balanceFee+checksFee;
        cout<<"The total Bank's service fees is: "<<total<<"$"<<endl<<endl;

        }
}
   return 0;
}
