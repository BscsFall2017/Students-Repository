#include <iostream>

using namespace std;

int main()
{
    int month, year;
    cout << "Tell me the year and the number of the month and I'll tell\nyou how many days the month has.\n";
    cout << "Enter month (1-12): ";
    cin >> month;
    cout << "Enter a year: " << endl;
    cin >> year;

        if (month==1)
            cout << "31 Days";
        else if ( (month==2)&& (year%100==0 && year%400==0) || (year%100!=0 && year%4==0))
        {
            cout << "29 Days";
        }
        else
            {
                cout << "28 Days";
            }
        if (month == 3)
            cout << "31 Days";
        else if (month == 4)
            cout << "30 Days";
        else if (month == 5)
            cout << "31 Days";
        else if (month == 6)
            cout << "30 Days";
        else if (month == 7)
            cout << "31 Days";
        else if (month == 8)
            cout << "30 Days";
        else if (month == 9)
            cout << " 31 Days";
        else if (month == 10)
            cout << "30 Days";
        else if (month == 11)
            cout << "31 Days";
        else if (month == 12)
            cout << "30 Days";
        else if (month > 12 && month <0)
            cout << "Sorry, you need to input any number between 1-12.";

    return 0;
}
