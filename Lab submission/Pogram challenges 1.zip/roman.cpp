#include <iostream>

using namespace std;

int main()
{
    int number;
    cout << "Roman Numeral Converter" << endl;
    cout << "Enter Number (1-10)" << endl;
    cin >> number;
    while (number<1||number>10)
    {
        cout << "Please enter a valid number" << endl;
        cin >> number;
    }
    switch (number)
    {
        case 1:cout << "The Roman Numeral Version of " << number << " is I" << endl;
        break;
        case 2:cout << "The Roman Numeral Version of " << number << " is II" << endl;
        break;
        case 3:cout << "The Roman Numeral Version of " << number << " is III" << endl;
        break;
        case 4:cout << "The Roman Numeral Version of " << number << " is IV" << endl;
        break;
        case 5:cout << "The Roman Numeral Version of " << number << " is V" << endl;
        break;
        case 6:cout << "The Roman Numeral Version of " << number << " is VI" << endl;
        break;
        case 7:cout << "The Roman Numeral Version of " << number << " is VII" << endl;
        break;
        case 8:cout << "The Roman Numeral Version of " << number << " is VIII" << endl;
        break;
        case 9:cout << "The Roman Numeral Version of " << number << " is IX" << endl;
        break;
        case 10:cout << "The Roman Numeral Version of " << number << " is X" << endl;
        break;
        default:cout << "Invalid Number" << endl;
    }
    return 0;
}
