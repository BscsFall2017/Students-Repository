#include <iostream>
using namespace std;

//functions used
bool leapYear(int);

int dayNumber(int, int, int);



int main ()

{

    int month;

    int day;

    int year;

    int leap;

int number;

    //get the date
    cout << "Enter a date in integer form (month day year): ";
    cin >> month >> day >> year;

    //determine if leap year is true or false using function

    leap = leapYear(year);
    //compute the day number using function

    number = dayNumber(month, day, leap);



    //display results

    cout << "The day number on the given date is: " << number << endl;



    //display if leap year is true or false
    if (leap == 1)

    cout << "The year entered is a leap year: true" << endl;


    if (leap == 0)

    cout << "The year entered is a leap year: false" << endl;



}


//function to determine if leap year is true or false, using integers 1 or 0

bool leapYear(int year)

{

    if (year % 400 == 0)

    {

        return true;

    }

    if (year % 100 == 0)
    {

        return false;

    }

    if (year % 4 == 0)

    {

        return true;

    }

    if (year % 4 !=0)

    {

        return false;

    }

}



//compute day number, adjusting for leap years

int dayNumber(int month, int day, int leap)

{

    if (month == 1)

    {

        return day;

    }

    if (month == 2)

    {

        return 31 + day;

    }

    if (month == 3)

    {

        return 59 + day + leap;

    }

    if (month == 4)

    {

        return 90 + day + leap;

    }

    if (month == 5)

    {

        return 120 + day + leap;

    }

    if (month == 6)

    {

        return 151 + day + leap;

    }

    if (month == 7)

    {

        return 181 + day + leap;

    }

    if (month == 8)

    {

        return 212 + day + leap;

    }

    if (month == 9)

    {

        return 243 + day + leap;

    }

    if (month == 10)
    {

        return 273 + day + leap;

    }

    if (month == 11)

    {

        return 304 + day + leap;

    }

    if (month == 12)

    {

        return 334 + day + leap;

    }
}


