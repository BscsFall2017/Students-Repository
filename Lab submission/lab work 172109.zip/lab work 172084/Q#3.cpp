#include<iostream>
using namespace std;
int main()
{
	float speed,time,distance;
	
	for(int i=1;i>=1;i++)
{
		cout<<"Please Enter the speed in miles\hour"<<endl;
	cin>>speed;
	cout<<"Please Enter the time traveled in hours"<<endl; 
	cin>>time;
	distance=time*speed;
	cout<<"the distance travelled is "<<distance<<" miles"<<endl;
}
}
