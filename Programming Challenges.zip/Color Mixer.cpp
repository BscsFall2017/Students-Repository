// Ch Jahanzaib
// programme for colour mixer
#include <iostream>
using namespace std;
int main()
{
   string color1, color2;
   cout <<"Enter two colors:- ";
   cin>> color1;
   cin>> color2;
   if((color1=="red" && color2=="blue")||(color2=="red" && color1=="blue")) //user can exchange colours 
   {
       cout<<"If we add "<<color1<<" + "<<color2<<" = PURPLE."<<endl<<endl;
   }
   else if((color1=="red" && color2=="yellow")||(color2=="red" && color1=="yellow"))
   {
       cout<<"If we add "<<color1<<" + "<<color2<<" = ORANGE."<<endl<<endl;
   }
   else if((color1=="blue" && color2=="yellow")||(color2=="blue" && color1=="yellow"))
   {
       cout<<"If we add "<<color1<<" + "<<color2<<" = GREEN."<<endl<<endl;
   }
   else
   {
   cout<<"Error please enter the correct colour"<<endl<<endl;
   }
   return 0;
}
