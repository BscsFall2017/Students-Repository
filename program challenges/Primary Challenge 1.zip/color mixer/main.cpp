#include <iostream>
#include <string>
using namespace std;

int main()
{
    string color1,color2;
    int red,blue,yellow;

    red=1;
    blue=2;
    yellow=3;

    cout<<"please enter two primary colors"<<endl;

    cout<<"enter color one"<<endl;
    cin>>color1;
    cout<<"enter color two"<<endl;
    cin>>color2;

    if(color1 == "red" && color2 == "blue")
    {
        cout<<" the two colors make purple"<<endl;
    }
    else if(color1 == "red" && color2 == "yellow")
    {
        cout<<"the two colors make orange"<<endl;
    }
    else if(color1 == "blue" && color2 == "yellow")
    {
        cout<<"the two colors make green"<<endl;
    }
    else
    {
        cout<<"invalid input...."<<endl;
    }

}
