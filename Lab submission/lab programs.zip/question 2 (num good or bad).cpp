#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"Enter the number:"<<endl;
	cin>>num;
	if(num>5||num>9||num>33)
	{
		cout<<"GOOD";
	}
	else
	{
		cout<<"BAD";
	}
	
	
}
