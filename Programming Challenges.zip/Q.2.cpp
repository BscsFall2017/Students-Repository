// Mahad
#include <iostream>
 
using namespace std;

int main()
{	
	int number;
	cout << "Enter a Number Between 1 and 10: ";
	cin >> number;
	switch (number)
	 {
	 	case 1: cout << "Roman Numeral version of 1 is: " << "i";
	 	break;
	 	case 2: cout << "Roman Numeral version of 2 is: " << "ii";
	 	break;
	 	case 3: cout << "Roman Numeral version of 3 is: " << "iii";
	 	break;
	 	case 4: cout << "Roman Numeral version of 4 is: " << "iv";
	 	break;
	 	case 5: cout << "Roman Numeral version of 5 is: " << "v";
	 	break;
	 	case 6: cout << "Roman Numeral version of 6 is: " << "vi";
	 	break;
	 	case 7: cout << "Roman Numeral version of 7 is: " << "vii";
	 	break;
	 	case 8: cout << "Roman Numeral version of 8 is: " << "viii";
	 	break;
	 	case 9: cout << "Roman Numeral version of 9 is: " << "ix";
	 	break;
	 	case 10: cout << "Roman Numeral version of 10 is: " << "x";
	 	break;
	 	default : cout <<"Invalid Number.\n";
	 	cout <<"You Should Enter a Number Between 1 and 10.";
	 }
		return 0;
}

