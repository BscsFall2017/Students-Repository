#include <iostream>

using namespace std;

int main()
{

    int number1,number2,number3;
    cout<<"Enter Three integer:";
    cin>>  number1 >>  number2  >>   number3;
   
    if(number1>number2&&number1>number3)
    {
        cout<<"number1 is the greatest";
    }
    if(number2>number1&&number2>number3)
    {
        cout<<"number2 is the greatest";
    }
    if(number3>number1&&number3>number2)
    {
    	cout<<"number3 is greatest";
}

    return 0;
}

