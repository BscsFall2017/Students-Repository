#include <iostream>

using namespace std;

int main()
{
    int n1, n2, n3;
cout<<"enter three numbers to know the largest one :"<<endl;
cin>>n1>>n2>>n3;

if(n1>n2 && n1>n3){
    cout<<"largest number : "<<n1<<endl;

}
if(n2>n1 && n2>n3){
    cout<<"largest number : "<<n2<<endl;

}
if(n3>n1 && n3>n2){
    cout<<"largest number : "<<n3<<endl;
}

    return 0;
}
