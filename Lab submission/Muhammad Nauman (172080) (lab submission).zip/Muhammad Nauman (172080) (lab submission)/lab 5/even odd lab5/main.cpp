#include <iostream>

using namespace std;

int main()
{

int num;
cout<<"Enter a number: "<<endl;
cin>>num;
if(num%2==0 && num>=1 && num<=10 ){
    cout<<num<<"   number is even:"<<endl;
}
if(num%2==0 && num>=21 && num<=40 )
{
    cout<<num<<"   number is even:"<<endl;
}

if(num%2==0 && num>=41 && num<=80 )
{
    cout<<num<<"   number is even:"<<endl;
}

if(num%2==0 && num>=81 && num<=100 )
{
    cout<<num<<"   number is even:"<<endl;
}

//odd

if(num%2==!0 && num>=1 && num<=10 ){
    cout<<num<<"   number is odd:"<<endl;
}
if(num%2==!0 && num>=21 && num<=40 )
{
    cout<<num<<"   number is odd:"<<endl;
}

if(num%2==!0 && num>=41 && num<=80 )
{
    cout<<num<<"   number is odd:"<<endl;
}

if(num%2 ==!0 && num>=81 && num<=100 )
{
    cout<<num<<"   number is odd:"<<endl;
}
    return 0;
}
