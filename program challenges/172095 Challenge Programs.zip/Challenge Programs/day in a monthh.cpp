#include <iostream>
using namespace std;
int main()
//function will return total number of days
{int  days, month,year;
cout<<"the program calculates the days in a month"<<endl;
cout<<"enter the month: "<<endl;
cin>>month;
cout<<"enter the year: "<<endl;
cin>>year;

	//leap year condition, if month is 2
	if( month == 2)
	{
		if((year%400==0) || (year%4==0 && year%100!=0))
			cout<<"days= 29";
		else
			cout<<"days= 28";
	}
	//months which has 31 days
	else if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8
	||month == 10 || month==12)
		cout<<"days= 31";
	else
		cout<<"days= 30";
}
