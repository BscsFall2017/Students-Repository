#include <iostream>

using namespace std;

int main()
{
    //Declare the variables
    float starting_balance, numOfChecks, monthlyfees=10, bankFees, checkFees;
    cout << "This program will computer and display the bank's service fees for the month.\n";
    cout << "Please enter your starting balance.\n";
    cin >> starting_balance;
    cout << "Please enter the number of checks written.\n";
    cin >> numOfChecks;

    //Make the formula
    bankFees=starting_balance-10-checkFees;

    //Apply the logic for bank fees
    {
        if (numOfChecks<20)
    {
        checkFees = 0.10;
    }
    else if (numOfChecks>=20 && numOfChecks<=39)
    {
        checkFees = 0.08;
    }
    else if (numOfChecks>=40 && numOfChecks<=59)
    {
        checkFees = 0.06;
    }
    else if (numOfChecks>=60)
    {
        checkFees = 0.04;
    }
    }
    //Logic if balance is less than $400.
    if (starting_balance<400)
    {
        bankFees = starting_balance-10-checkFees-15;
    }

    if (numOfChecks<0)
        cout << "Negative value for number of checks written is not accepted.\n";

    if (starting_balance<0)
        cout << "The account is overdrawn.\n";

    //Make the formula
    bankFees=starting_balance-10-checkFees;

    cout << "The bank's service fees for the month are $" << bankFees << ".\n";
    return 0;
}
