#include <iostream>

using namespace std;

int main()
{
    int number,rem;
    cout <<" Enter a number" << endl;
    cin>>number;

rem=number%2;

if(number>1&&number<100){

cout<<"     ** valid **"<<endl;

if(number>1&&number<10&&rem==0){
    cout<<"   The  number  is even   ";
}

if(number>21&&number<40&&rem==0){
    cout<<"   The  number  is even   ";
}



if(number>41&&number<80&&rem==0){
    cout<<"   The  number  is even   ";
}




if(number>81&&number<100&&rem==0){
    cout<<"   The  number  is even   ";
}






if(number>1&&number<10&&rem!=0){
    cout<<"   The  number  is 0dd  ";
}

if(number>21&&number<40&&rem!=0){
    cout<<"   The  number  is  odd  ";
}



if(number>41&&number<80&&rem!=0){
    cout<<"   The  number  is odd   ";
}




if(number>81&&number<100&&rem!=0){
    cout<<"   The  number  is odd  ";
}







































}























}
