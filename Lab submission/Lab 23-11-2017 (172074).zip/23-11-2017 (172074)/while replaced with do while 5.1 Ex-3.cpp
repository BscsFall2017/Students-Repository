// FARAZ ALI

#include <iostream>
using namespace std;

int main()
{
	char letter = 'a';
    do
    {
           cout << "Please enter a letter" << endl;
           cin >> letter;
           cout << "The letter you entered is " << letter << endl;
    }while (letter != 'x');//Now it will print "The letter you entered is x" and then the condition becomes false and program stops running. . .


    return 0;
}
