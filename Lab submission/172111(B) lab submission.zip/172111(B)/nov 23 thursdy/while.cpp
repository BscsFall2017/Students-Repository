// PLACE YOUR NAME HERE



//program is not user friendly
//using infinite loop
//not a proper direction for the loop

#include <iostream>
using namespace std;

int main()
{
	char letter = 'a';

    while (letter != 'x' )
	{
           cout << "Please enter a letter" << endl;

cout<<"Enter x to quit the program."<<endl;
cin>>letter;

           cout << "The letter you entered is " << letter << endl;
    }

    return 0;
}
