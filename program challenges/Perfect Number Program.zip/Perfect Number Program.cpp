#include <iostream>

using namespace std;

int main()
{
    //Declare and define variables
    int number, sum=0, iteration=1;

    //Get input from the user
    cout << "Hello, this program will tell you if your number is perfect or not." << endl;
    cout << "Enter any number.\n";
    cin >> number;

    int first=number; //Meh
    //Let the loop begin
    while (number>iteration)
    {
        if (number%iteration==0)
            sum +=iteration;

        iteration++;
    }
    if (sum==number)
        cout << "The number " << first << " is a perfect number.\n";
    else
        cout << "The number " << first << " is not a perfect number.\n";

    return 0;
}
