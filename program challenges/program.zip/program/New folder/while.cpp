// PLACE YOUR NAME HERE

#include <iostream>
using namespace std;

int main()
{
	char letter = 'a';
	cout<<"please enter the letters"<<endl;
    while (letter != 'x')
	{
           cin >> letter;
           cout << letter << endl;
    }

	return 0;	
}
