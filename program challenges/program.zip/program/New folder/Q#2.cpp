#include <iostream>
using namespace std;

int main()
{
int num[] = {1,2,3,4,5,6,7,8,9,10};
int max,min,a;

cout<<"Enter 10 integers: ";

for (int a=0;a<10;a++);
	{
	cin>>num[a];
	}


max = num[0];
min = num[0];

for (int a=1;a<10;a++)
	{
		if(max<num[a])
		{
		max=num[a];
		}
		else if (min>num[a])
		{
		min=num[a];
		}
	}
	cout<<"Maximum value is "<<max<<endl;
cout<<"Minumum value is "<<min<<endl;
return 0;
}
