// PLACE YOUR NAME HERE

#include <iostream>
using namespace std;

int main()
{
	char letter = 'a';

    cout << "This program will not terminate unless you put in the letter x.\n";
    while (letter != 'x')
	{
           cout << "Please enter a letter" << endl;
           cin >> letter;
           cout << "The letter you entered is " << letter << endl;
    }

    return 0;
}
