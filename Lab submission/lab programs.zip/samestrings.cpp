#include <iostream>
#include <string>
using namespace std;

int main()
{
    string str1;
    string str2;
    cout <<"enter 1st string"  <<endl;
    cin>>str1;
    cout <<"enter 2nd string"  <<endl;
    cin>>str2;
    
    int result;
    if(str1=compareTo(str2))
    {
    	cout<<"strings equal";
	}
    
  /*  if(result==0)
    {
       cout<<"both are equal"   ; 
    }
    */
    
    
    
    return 0;
}
